# LA MAGIA DEL NATALE — progetto Android NUOVO (1.0)

Questo progetto è stato riscritto da zero, senza riprendere il codice delle versioni V1–V16. Ha anche un nuovo identificativo Android, `it.lamagiadelnatale.app`, per installarsi a fianco dell'app vecchia e non subire conflitti di firma.

## Funzionalità realmente programmate

- Home natalizia azzurra, illustrata, con sezioni film, libri, Avvento, programmi TV e film gratuiti legali.
- Catalogo **offline** di **49 film** e **30 libri** con informazioni, ricerca, filtri e schede dettagliate.
- Preferiti e film già visti salvati **localmente** sul dispositivo (nessun login necessario).
- Calendario dell'Avvento di **24 caselline**: un film + un libro per giorno, attivazione quotidiana in dicembre, anteprima da Preferiti per collaudo.
- Film: verifica dello streaming tramite ricerca aggiornata JustWatch e link alle piattaforme. Nessuna piattaforma è dichiarata disponibile senza conferma.
- Film gratuiti: link a RaiPlay, Mediaset Infinity, Pluto TV, YouTube. Nessun contenuto pirata e nessuna falsa disponibilità gratuita.
- Immagini: ricerca del vero materiale editoriale attraverso **iTunes Search API** per film (poster + collegamento Apple TV) e **Google Books/Open Library** per libri (titolo/autore). Verifica degli abbinamenti; se mancano, segnaposto esplicito.
- Guida TV: 7 date selezionabili; prova 8 canali RaiPlay in tempo reale, mostra gli orari soltanto quando arrivano realmente. Per TV8, Mediaset e Sky include collegamenti alle rispettive guide ufficiali. In caso di fonte vuota, mostra un errore leggibile.
- Promemoria facoltativi (30 minuti prima) su APK Android con notifiche native; orario indicativo, senza promessa di esattezza assoluta.
- Link Amazon separati per libro cartaceo e Kindle. ID affiliato memorizzato nella configurazione, ma tracking **disattivato nella build Android** in attesa di autorizzazione Amazon Associates per questa specifica app.
- Spazi pubblicitari indicati, **AdMob non attivo** in assenza di account, ID unità e consenso privacy.

## Non sono ancora garantiti

- Poster per tutti i titoli: solo quando disponibili e correttamente associati nelle API. Le licenze per impieghi commerciali devono essere verificate.
- Orari TV per 7 giorni completi: dipendono dai dati forniti dall'emittente; i canali TV8/Sky non sono integrabili legalmente senza accordo o API autorizzata.
- Disponibilità streaming precisa in tempo reale: serve una partnership con un fornitore che autorizzi il riuso commerciale dei dati (es. JustWatch B2B).
- Codice affiliato attivo e annunci AdMob: servono prima approvazioni e identificativi reali.
- Accesso multi-dispositivo e autenticazione: i preferiti sono al momento locali.

## Compilazione Android

**Requisiti:** Android SDK Platform 35, JDK 17, Gradle 8.10.2, Android Gradle Plugin 8.7.3.

1. Aprire questa cartella in Android Studio oppure in Codex Cloud con Android SDK disponibile.
2. Eseguire `gradle --no-daemon :app:assembleDebug` dalla cartella principale.
3. L'APK debug sarà `app/build/outputs/apk/debug/app-debug.apk`.
4. Verificarne la firma con `apksigner verify --verbose app-debug.apk` e installarlo su Android 8.0 o successivo.
5. Testare sul dispositivo reale Home, film, libri, Avvento, connessioni immagini, guida oggi e domani.

Il nuovo `applicationId` previene il conflitto di aggiornamento con il vecchio APK firmato da un'altra chiave. Non serve disinstallare l'app precedente per testare la nuova.

## Prove svolte in questa sessione

- Controllo sintattico `node --check` di `app.js` superato.
- Test JavaScript automatizzato del catalogo e delle interazioni (`node tests/check.js`) superato.
- Test dell'interpretazione di palinsesti **simulati** per oggi e domani superato, anche tramite simulazione del ponte nativo Android (`node tests/native_bridge.js`).
- **Non** è stata effettuata una compilazione APK in questo ambiente, perché qui non sono installati né Android SDK né Gradle.
- **Non** è stato possibile verificare le chiamate Internet reali dal dispositivo Samsung.

## Note sulle fonti e sull'uso commerciale

- RaiPlay: feed pubblico sperimentale; verificare autorizzazione al riutilizzo commerciale. Se l'endpoint cambia o smette di rispondere, non inventare programmi.
- Apple: il materiale promozionale deve essere associato alla relativa scheda Apple TV e soggetto ai termini Apple.
- Google Books e Open Library: usare metadati e immagini solo entro i termini del servizio.
- TMDB: la licenza gratuita è per usi non commerciali; per annunci/sponsorizzazioni serve licenza appropriata.
- Amazon Associates: verificare le condizioni per le app mobili; i link cartaceo/Kindle della build di test sono **non affiliati**.

## Descrizione del progetto

Nome: **La Magia del Natale**. Identità: azzurro, blu notte, bianco neve, oro, luci natalizie, decorazioni ricche e testi leggibili. Una piattaforma di scoperta: **non** distribuisce film in streaming né vende direttamente libri.
