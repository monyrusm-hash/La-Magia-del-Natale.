import json
from pathlib import Path
# TITLE | original-language title | year | category | concise factual synopsis (not copied) | genre
movie_lines='''
Mamma, ho perso l’aereo|Home Alone|1990|famiglia|Kevin rimane a casa da solo durante le feste e si difende da due ladri.|Commedia
Mamma, ho riperso l’aereo: mi sono smarrito a New York|Home Alone 2: Lost in New York|1992|famiglia|Kevin affronta una nuova avventura natalizia a New York.|Commedia
Klaus - I segreti del Natale|Klaus|2019|animazione|Un postino e un giocattolaio cambiano la vita di una città innevata.|Animazione
Polar Express|The Polar Express|2004|animazione|Un viaggio in treno verso il Polo Nord alla scoperta dello spirito del Natale.|Animazione
A Christmas Carol|A Christmas Carol|2009|animazione|Scrooge incontra tre spiriti che gli mostrano il valore del Natale.|Animazione
Nightmare Before Christmas|The Nightmare Before Christmas|1993|animazione|Jack Skeletron scopre la città del Natale e sogna di cambiarne la festa.|Animazione
Il Grinch|The Grinch|2018|animazione|Il Grinch cerca di rovinare il Natale agli abitanti di Chinonso.|Animazione
Il Grinch|How the Grinch Stole Christmas|2000|famiglia|Una creatura burbera vuole rubare la gioia natalizia della cittadina.|Commedia
Arthur Christmas - Il figlio di Babbo Natale|Arthur Christmas|2011|animazione|Arthur tenta una missione speciale per consegnare l'ultimo regalo.|Animazione
Il canto di Natale di Topolino|Mickey's Christmas Carol|1983|animazione|Personaggi Disney reinterpretano la storia di Scrooge.|Animazione
Il figlio di Babbo Natale|The Santa Clause|1994|famiglia|Un padre scopre di dover diventare Babbo Natale.|Commedia
Che fine ha fatto Santa Clause?|The Santa Clause 2|2002|famiglia|Babbo Natale deve trovare una moglie prima di una scadenza magica.|Commedia
Elf - Un elfo di nome Buddy|Elf|2003|comico|Un ragazzo cresciuto dagli elfi cerca il padre a New York.|Commedia
Una poltrona per due|Trading Places|1983|comico|Due uomini si ritrovano coinvolti in uno scambio di vite tra le feste.|Commedia
Vacanze di Natale|Vacanze di Natale|1983|comico|Famiglie e amici si incrociano durante le vacanze a Cortina.|Commedia
National Lampoon's Christmas Vacation|National Lampoon's Christmas Vacation|1989|comico|Una famiglia vive disavventure durante i preparativi natalizi.|Commedia
Fuga dal Natale|Christmas with the Kranks|2004|comico|Una coppia prova a saltare il Natale, con conseguenze imprevedibili.|Commedia
Jingle All the Way|Jingle All the Way|1996|famiglia|Un padre cerca il giocattolo più richiesto all'ultimo minuto.|Commedia
Il miracolo della 34ª strada|Miracle on 34th Street|1994|classico|Un uomo sostiene di essere Babbo Natale e conquista una bambina scettica.|Famiglia
Miracolo sulla 34ª strada|Miracle on 34th Street|1947|classico|Un commesso dei grandi magazzini afferma di essere il vero Babbo Natale.|Classico
La vita è meravigliosa|It's a Wonderful Life|1946|classico|Un uomo vede come sarebbe la vita senza di lui, alla vigilia di Natale.|Classico
Il piccolo Lord|Little Lord Fauntleroy|1980|classico|Un bambino visita un anziano e severo nonno in Inghilterra.|Famiglia
Love Actually - L'amore davvero|Love Actually|2003|romantico|Storie d'amore si intrecciano nella Londra natalizia.|Romantico
L'amore non va in vacanza|The Holiday|2006|romantico|Due donne si scambiano casa durante le vacanze e incontrano nuovi amori.|Romantico
Last Christmas|Last Christmas|2019|romantico|Un incontro imprevisto cambia le prospettive di una giovane londinese.|Romantico
Serendipity - Quando l'amore è magia|Serendipity|2001|romantico|Due sconosciuti si affidano al destino dopo un incontro a New York.|Romantico
The Family Man|The Family Man|2000|romantico|Un uomo di successo scopre come sarebbe una diversa vita familiare.|Romantico
Natale a 5 stelle|Natale a 5 stelle|2018|comico|Una vacanza ufficiale si trasforma in una serie di equivoci.|Commedia
Il peggior Natale della mia vita|Il peggior Natale della mia vita|2012|comico|Un Natale in famiglia diventa un susseguirsi di imprevisti.|Commedia
Qualcuno salvi il Natale|The Christmas Chronicles|2018|famiglia|Due fratelli si ritrovano in una notte inaspettata con Babbo Natale.|Avventura
Qualcuno salvi il Natale 2|The Christmas Chronicles 2|2020|famiglia|Una nuova minaccia mette in pericolo il villaggio di Babbo Natale.|Avventura
Un bambino chiamato Natale|A Boy Called Christmas|2021|famiglia|Un ragazzino parte alla ricerca del padre e di un luogo leggendario.|Fantastico
Noelle|Noelle|2019|famiglia|La figlia di Babbo Natale cerca il fratello destinato a guidare la slitta.|Commedia
Spirited - Magia di Natale|Spirited|2022|comico|Una moderna rilettura musicale della storia di Scrooge.|Musical
Un principe per Natale|A Christmas Prince|2017|romantico|Una giornalista arriva in un piccolo regno per un incarico natalizio.|Romantico
Nei panni di una principessa|The Princess Switch|2018|romantico|Due donne molto somiglianti si scambiano la vita per le feste.|Romantico
Un castello per Natale|A Castle for Christmas|2021|romantico|Una scrittrice parte per la Scozia e si affeziona a un castello.|Romantico
Falling for Christmas|Falling for Christmas|2022|romantico|Un incidente cambia le vacanze di una ricca ereditiera.|Romantico
Holidate|Holidate|2020|romantico|Due single scelgono di accompagnarsi alle festività senza impegno.|Commedia
Il diario segreto di Noel|The Noel Diary|2022|romantico|Un uomo torna a casa per Natale e scopre vecchie storie familiari.|Romantico
Single per sempre?|Single All the Way|2021|romantico|Un giovane torna in famiglia per Natale con il suo migliore amico.|Commedia
Natale con te|Christmas with You|2022|romantico|Una cantante riscopre l'ispirazione durante le feste.|Romantico
Questo Natale|That Christmas|2024|animazione|Storie familiari e piccoli imprevisti si incontrano in una comunità innevata.|Animazione
Candy Cane Lane|Candy Cane Lane|2023|famiglia|Una gara di decorazioni natalizie prende una piega incantata.|Commedia
Dashing Through the Snow|Dashing Through the Snow|2023|famiglia|Una bambina e suo padre vivono una notte di magia natalizia.|Commedia
Family Switch|Family Switch|2023|famiglia|Una famiglia si risveglia nei corpi degli altri a pochi giorni dal Natale.|Commedia
Il canto di Natale dei Muppet|The Muppet Christmas Carol|1992|famiglia|I Muppet raccontano la trasformazione di Ebenezer Scrooge.|Commedia
Il pupazzo di neve|The Snowman|1982|animazione|Un pupazzo di neve prende vita per una notte speciale.|Animazione
Il Natale di Angela|Angela's Christmas|2017|animazione|Una bambina irlandese vuole assicurarsi che tutti stiano al caldo a Natale.|Animazione
Una famiglia al tappeto|? |2019|comico|Un film da riscoprire nella stagione delle feste.|Commedia
'''.strip().splitlines()
# Drop items not a certain Christmas film
movie_lines=[x for x in movie_lines if 'Una famiglia al tappeto' not in x]
films=[]
for i,line in enumerate(movie_lines,1):
 p=line.split('|')
 if len(p)!=6:print('invalid',line);continue
 t,original,year,category,summary,genre=p
 films.append({'id':f'f{i:03d}','title':t,'original':original,'year':int(year),'category':category,'synopsis':summary,'genre':genre})
# Book titles are real works. Edition matching happens through API; no fabricated ISBN.
book_lines='''
Canto di Natale|Charles Dickens|classico|Il grande racconto di Scrooge, dei tre spiriti e della generosità natalizia.
Lo schiaccianoci e il re dei topi|E. T. A. Hoffmann|fantasia|Un'avventura fantastica tra giocattoli viventi e mondi incantati.
Il Grinch|Dr. Seuss|bambini|Una creatura burbera scopre il vero significato del Natale.
Polar Express|Chris Van Allsburg|bambini|Un treno misterioso conduce i bambini fino al Polo Nord.
Lettere da Babbo Natale|J. R. R. Tolkien|famiglia|Le lettere immaginarie scritte da Babbo Natale ai figli di Tolkien.
Un ragazzo chiamato Natale|Matt Haig|fantasia|La storia di un bambino alla ricerca della magia del Natale.
La bambina che salvò il Natale|Matt Haig|fantasia|Una nuova avventura nel magico mondo delle feste.
Babbo Natale e io|Matt Haig|fantasia|Una storia ambientata nel villaggio degli elfi con una giovane protagonista.
Il Natale di Poirot|Agatha Christie|giallo|Un mistero riunisce Hercule Poirot e una famiglia durante le feste.
Il pianeta degli alberi di Natale|Gianni Rodari|bambini|Un viaggio fantastico nel mondo dove è sempre Natale.
La freccia azzurra|Gianni Rodari|bambini|I giocattoli affrontano un viaggio per raggiungere un bambino.
Il dono dei Magi|O. Henry|classico|Un racconto breve sull'amore e sul valore dei regali.
Ricordo di Natale|Truman Capote|classico|Un ricordo delicato di un Natale dell'infanzia.
La notte prima di Natale|Clement C. Moore|bambini|Il classico poema dedicato alla notte dell'arrivo di Babbo Natale.
Il pupazzo di neve|Raymond Briggs|bambini|Una storia illustrata di amicizia e una notte sulla neve.
Babbo Natale|Raymond Briggs|bambini|Il lato quotidiano e divertente della vita di Babbo Natale.
Il maialino di Natale|J. K. Rowling|fantasia|Un bambino affronta una straordinaria avventura per ritrovare il suo amico.
The Christmasaurus|Tom Fletcher|fantasia|Un ragazzino scopre un Natale pieno di dinosauri e meraviglie.
Fuga dal Natale|John Grisham|commedia|Una coppia decide di non festeggiare il Natale, con conseguenze comiche.
Miracolo nella 34ª strada|Valentine Davies|classico|La storia che ha ispirato il famoso film natalizio.
La vita e le avventure di Babbo Natale|L. Frank Baum|fantasia|Un racconto fantastico sulle origini di Babbo Natale.
Il mistero del Natale|Jostein Gaarder|fantasia|Un calendario misterioso rivela una storia a tappe.
Il leone, la strega e l'armadio|C. S. Lewis|fantasia|Quattro fratelli scoprono il regno di Narnia coperto da un lungo inverno.
Piccole donne|Louisa May Alcott|classico|Quattro sorelle crescono condividendo gioie, difficoltà e anche il Natale.
Canto di Natale|Geronimo Stilton|bambini|Una rivisitazione per giovani lettori del classico natalizio.
Le avventure di Pinocchio|Carlo Collodi|classico|Un classico da leggere durante le vacanze in famiglia.
A Christmas Memory|Truman Capote|classico|Un ricordo commovente della preparazione del Natale.
How the Grinch Stole Christmas!|Dr. Seuss|bambini|Un grande classico illustrato sul significato delle feste.
The Gift of the Magi|O. Henry|classico|Un breve racconto che celebra il dono e il sacrificio.
The Nutcracker|E. T. A. Hoffmann|fantasia|La favola fantastica dello Schiaccianoci in lingua originale.
'''.strip().splitlines()
books=[]
for i,line in enumerate(book_lines,1):
 t,auth,category,summary=line.split('|')
 books.append({'id':f'b{i:03d}','title':t,'author':auth,'category':category,'synopsis':summary})
# Advent pairings avoid duplication across 24 days
advent=[]
for i in range(24):
 advent.append({'day':i+1,'filmId':films[(i*2+3)%len(films)]['id'],'bookId':books[i]['id'],'message':['Accendi una luce di gentilezza.','Un piccolo gesto rende speciale il Natale.','Lascia spazio alle storie che fanno sognare.','La magia è nelle persone che ami.'][i%4]})
asset=Path('/mnt/data/La_Magia_del_Natale_Nuova/app/src/main/assets')
(asset/'catalogo.json').write_text(json.dumps({'films':films,'books':books,'advent':advent},ensure_ascii=False,indent=2),encoding='utf8')
print('FILMS',len(films),'BOOKS',len(books),'ADVENT',len(advent))
