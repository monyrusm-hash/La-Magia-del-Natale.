'use strict';
const fs=require('fs'),vm=require('vm'),path=require('path');
const root=path.resolve(__dirname,'../app/src/main/assets');
const catalog=fs.readFileSync(path.join(root,'catalogo.js'),'utf8');
const app=fs.readFileSync(path.join(root,'app.js'),'utf8');
const els={app:{innerHTML:''},toast:{classList:{add(){},remove(){}},textContent:''}};
const storage={};let calls=0;let ctx;
const android={
 fetchJson(url,id){calls++;const payload=url.includes('raiplay.it')?{events:[{name:'Klaus - I segreti del Natale',hour:'15:45',genre:'Film'}]}:url.includes('itunes.apple.com')?{results:[]}:url.includes('googleapis')?{items:[]}:{docs:[]};
   setTimeout(()=>ctx.window.AppNative.onResponse(id,200,JSON.stringify(payload)),3);
 },openExternal(){},remind(){},platform(){return 'android'}
};
ctx={document:{querySelectorAll(){return []},getElementById(id){return els[id]||null}},window:{AndroidBridge:android,scrollTo(){}},AndroidBridge:android,
  localStorage:{getItem:k=>storage[k]||null,setItem:(k,v)=>storage[k]=v},Date,URL,URLSearchParams,console,Set,Map,Promise,Intl,setTimeout,clearTimeout};
vm.createContext(ctx);vm.runInContext(catalog+'\n'+app,ctx);
ctx.window.App.go('tv');
setTimeout(()=>{
 if(!els.app.innerHTML.includes('Klaus - I segreti del Natale'))throw Error('Guida TV tramite ponte Android non funziona');
 ctx.window.App.selectDay(1);
 setTimeout(()=>{
  if(!els.app.innerHTML.includes('Klaus - I segreti del Natale'))throw Error('Domani tramite ponte Android non funziona');
  console.log('OK: Ponte Android JSON, guida TV oggi/domani, '+calls+' richieste simulate.');
 },140);
},140);
