'use strict';
const vm=require('vm'),fs=require('fs'),path=require('path');
const root=path.join(__dirname,'../app/src/main/assets');
const code=fs.readFileSync(path.join(root,'catalogo.js'),'utf8')+'\n'+fs.readFileSync(path.join(root,'app.js'),'utf8');
const elm={app:{innerHTML:''},toast:{classList:{add(){},remove(){}},textContent:''},filmResults:{innerHTML:''},bookResults:{innerHTML:''},globalResults:{innerHTML:''}};
const storage={};
const document={querySelector(){return null},querySelectorAll(){return []},getElementById(k){return elm[k]||null}};
const events=[];
const fixture={'events':[{'name':'Klaus - I segreti del Natale','hour':'15:45','genre':'Film'},{'name':'TG1','hour':'20:00','genre':'News'}]};
const context={document,window:{scrollTo(){}},localStorage:{getItem:k=>storage[k]||null,setItem:(k,v)=>storage[k]=v},Date,URL,URLSearchParams,console,Set,Map,Promise,Intl,
  setTimeout:(fn,t)=>{if(t===0)fn();return 123},clearTimeout:()=>{},
  fetch:async url=>({ok:true,json:async()=>url.includes('palinsesto/app/')?fixture:{results:[],items:[],docs:[]}})};
vm.createContext(context);vm.runInContext(code,context);
const App=context.window.App;
function assert(ok,msg){if(!ok)throw Error('TEST FALLITO '+msg)}
(async()=>{
 assert(elm.app.innerHTML.includes('La Magia'), 'Home valorizzata');
 assert(elm.app.innerHTML.includes('Film gratuiti'), 'Film gratuiti');
 App.go('film'); assert(elm.app.innerHTML.includes('Mamma, ho perso l’aereo'),'Film catalogo');
 assert(elm.app.innerHTML.includes('49 film selezionati'),'Conteggio film');
 App.searchFilm('Klaus');assert(elm.filmResults.innerHTML.includes('Klaus'),'Ricerca film');
 App.detail('film','f003');assert(elm.app.innerHTML.includes('La trama'),'Scheda film');
 App.toggleFavorite('film','f003');assert(storage['magia-nuova-favorites'].includes('film:f003'),'Preferiti persistenti');
 App.go('libri');assert(elm.app.innerHTML.includes('Lettere da Babbo Natale'),'Catalogo libri');
 App.searchBook('Tolkien');assert(elm.bookResults.innerHTML.includes('Tolkien'),'Ricerca autore');
 App.detail('book','b005');assert(elm.app.innerHTML.includes('eBook Kindle'),'Link Kindle');
 App.go('avvento');assert((elm.app.innerHTML.match(/class="locked"/g)||[]).length===24,'24 caselline bloccate in novembre');
 App.go('preferiti');App.togglePreview();App.go('avvento');App.openDay(1);
 assert(elm.app.innerHTML.includes('Il dono del giorno 1'),'Anteprima dell’avvento');
 App.go('tv');await new Promise(r=>setTimeout(r,20));
 assert(elm.app.innerHTML.includes('Klaus - I segreti del Natale'),'Palinsesto oggi JSON');
 App.selectDay(1);await new Promise(r=>setTimeout(r,20));
 assert(elm.app.innerHTML.includes('Klaus - I segreti del Natale'),'Palinsesto domani JSON');
 App.tvFilter(false);assert(elm.app.innerHTML.includes('TG1'),'Filtro tutti i programmi');
 console.log('OK: Home ricca, 49 film, 30 libri, ricerca, dettagli, preferiti, 24 Avvento, TV oggi/domani con fixture, filtro TV.');
})().catch(e=>{console.error(e.stack);process.exitCode=1});
