package it.lamagiadelnatale.app;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context ctx,Intent intent) {
        if(Build.VERSION.SDK_INT>=33 && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!= PackageManager.PERMISSION_GRANTED) return;
        String title=intent.getStringExtra("title");
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(ctx,"films"):new Notification.Builder(ctx);
        Notification n=b.setContentTitle("La Magia del Natale 🎄")
            .setContentText("Tra poco in TV: "+(title==null?"il tuo film":title))
            .setSmallIcon(android.R.drawable.ic_dialog_info).setAutoCancel(true).build();
        ((NotificationManager)ctx.getSystemService(Context.NOTIFICATION_SERVICE)).notify((int)(System.currentTimeMillis()%100000),n);
    }
}
