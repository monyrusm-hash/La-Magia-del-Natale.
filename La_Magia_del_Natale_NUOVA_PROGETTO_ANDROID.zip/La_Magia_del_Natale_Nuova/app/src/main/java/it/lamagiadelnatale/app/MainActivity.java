package it.lamagiadelnatale.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView web;
    private final ExecutorService io = Executors.newFixedThreadPool(3);
    private static final Set<String> JSON_HOSTS = Set.of(
      "www.raiplay.it", "raiplay.it", "itunes.apple.com", "www.googleapis.com",
      "openlibrary.org", "api.themoviedb.org"
    );

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(15,65,112));
        getWindow().setNavigationBarColor(Color.rgb(235,248,255));
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel("films", "Promemoria film", NotificationManager.IMPORTANCE_DEFAULT);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(234,247,255));
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.getSettings().setAllowFileAccessFromFileURLs(false);
        web.getSettings().setAllowUniversalAccessFromFileURLs(false);
        web.getSettings().setMixedContentMode(android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.getSettings().setMediaPlaybackRequiresUserGesture(true);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                if ("file".equals(u.getScheme()) && "android_asset".equals(u.getAuthority())) return false;
                if ("https".equals(u.getScheme())) { openUrl(u.toString()); return true; }
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private void openUrl(String url) {
        try {
            Uri uri=Uri.parse(url);
            if (!"https".equals(uri.getScheme())) return;
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (Exception ignored) { }
    }
    @Override public void onBackPressed() {
        if (web!=null) web.evaluateJavascript("window.App && App.goBack ? App.goBack() : false", null);
        else super.onBackPressed();
    }
    @Override public void onDestroy(){ io.shutdownNow(); if(web!=null)web.destroy(); super.onDestroy(); }

    public class Bridge {
        @JavascriptInterface public void openExternal(String url){ runOnUiThread(() -> openUrl(url)); }
        @JavascriptInterface public String platform(){ return "android"; }
        // All remote API calls are HTTPS GET, fixed allowlist, background threads, 12s timeout.
        @JavascriptInterface public void fetchJson(final String target, final int id) {
            io.execute(() -> {
                int status=0; String result=""; HttpURLConnection conn=null;
                try {
                    URL url=new URL(target);
                    String host=url.getHost().toLowerCase(java.util.Locale.ROOT);
                    if(!"https".equalsIgnoreCase(url.getProtocol()) || !JSON_HOSTS.contains(host))
                        throw new SecurityException("Dominio non autorizzato");
                    conn=(HttpURLConnection)url.openConnection();
                    conn.setInstanceFollowRedirects(false);
                    conn.setConnectTimeout(9000); conn.setReadTimeout(12000);
                    conn.setRequestProperty("Accept", "application/json");
                    conn.setRequestProperty("User-Agent", "LaMagiaDelNatale/1.0 Android");
                    status=conn.getResponseCode();
                    InputStream in=status>=200&&status<300?conn.getInputStream():conn.getErrorStream();
                    if(in!=null){
                        try(in){ ByteArrayOutputStream buf=new ByteArrayOutputStream(); byte[] tmp=new byte[8192]; int n;
                            while((n=in.read(tmp))!=-1){if(buf.size()+n>2_000_000)throw new Exception("Risposta troppo grande"); buf.write(tmp,0,n);}
                            result=buf.toString(StandardCharsets.UTF_8.name());
                        }
                    }
                }catch(Exception ex){ result=ex.getClass().getSimpleName()+": "+ex.getMessage(); status=0; }
                finally{ if(conn!=null)conn.disconnect(); }
                final int s=status; final String body=result;
                runOnUiThread(()->{
                    if(web!=null) web.evaluateJavascript("window.AppNative && AppNative.onResponse("+id+","+s+","+JSONObject.quote(body)+")",null);
                });
            });
        }
        @JavascriptInterface public void remind(String title,long whenMs){
            runOnUiThread(()-> {
                if(whenMs<=System.currentTimeMillis()){Toast.makeText(MainActivity.this,"Orario già trascorso",Toast.LENGTH_SHORT).show();return;}
                try {
                    if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
                        requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},91);
                        Toast.makeText(MainActivity.this,"Autorizza le notifiche e premi di nuovo Avvisami",Toast.LENGTH_LONG).show(); return;
                    }
                    Intent it=new Intent(MainActivity.this, ReminderReceiver.class);
                    it.putExtra("title",title);
                    int requestId=(int)(whenMs%Integer.MAX_VALUE)^title.hashCode();
                    PendingIntent p=PendingIntent.getBroadcast(MainActivity.this,requestId,it,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
                    AlarmManager am=(AlarmManager)getSystemService(Context.ALARM_SERVICE);
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMs,p);
                    Toast.makeText(MainActivity.this,"Promemoria impostato (orario indicativo)",Toast.LENGTH_LONG).show();
                }catch(Exception ex){Toast.makeText(MainActivity.this,"Impossibile impostare il promemoria",Toast.LENGTH_LONG).show();}
            });
        }
    }
}
