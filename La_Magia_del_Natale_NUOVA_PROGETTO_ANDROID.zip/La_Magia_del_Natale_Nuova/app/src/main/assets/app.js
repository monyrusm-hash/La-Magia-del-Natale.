/* La Magia del Natale — app riscritta da zero, 2026. Niente programmi TV inventati. */
'use strict';
(() => {
  const FILMS = window.CATALOG.films, BOOKS=window.CATALOG.books, ADVENT=window.CATALOG.advent;
  const $=sel=>document.querySelector(sel);
  const byId=id=>document.getElementById(id);
  const safe =s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const slug=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();
  const normTitle=s=>slug(s).replace(/^the |^il |^lo |^la |^un |^una |^a /,'');
  const pad=n=>String(n).padStart(2,'0');
  const dateKey=d=>`${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
  const inDays=n=>{const d=new Date();d.setHours(12,0,0,0);d.setDate(d.getDate()+n);return d};
  const prettyDate=key=>new Date(`${key}T12:00:00`).toLocaleDateString('it-IT',{weekday:'long',day:'numeric',month:'long'});
  const displayDay=n=>n===0?'Oggi':n===1?'Domani':inDays(n).toLocaleDateString('it-IT',{weekday:'short',day:'numeric'});
  const filterText=safe;
  const store={
    get(key,fallback){try{const v=localStorage.getItem('magia-nuova-'+key);return v===null?fallback:JSON.parse(v)}catch(e){return fallback}},
    set(key,v){try{localStorage.setItem('magia-nuova-'+key,JSON.stringify(v))}catch(e){}}
  };
  const favorites=new Set(store.get('favorites',[]));
  const seen=new Set(store.get('seen',[]));
  const watched=new Set(store.get('watched',[]));
  const metadata=store.get('metadata',{});
  const cache=store.get('tv',{});
  const state={route:'home',detail:null,query:'',filmCategory:'tutti',bookCategory:'tutti',dateIndex:0,tvOnlyChristmas:true,
    tv:new Map(),adventPreview:store.get('previewAdvent',false),prefs:store.get('genres',['famiglia','animazione','romantico'])};
  const asset=(type,id)=>`${type}:${id}`;
  const isNative=!!window.AndroidBridge;
  const AMAZON_ASSOCIATES_TAG='monyka87-21';
  const AMAZON_APP_APPROVED=false; // Attivare solo dopo approvazione dell'app nel Programma Affiliazione Amazon.
  const OPEN_SOURCE_TV=[
    ['RaiPlay','https://www.raiplay.it/guidatv/'],
    ['Mediaset Infinity','https://mediasetinfinity.mediaset.it/guidatv'],
    ['TV8','https://www.tv8.it/programmazione'],
    ['Sky Guida TV','https://guidatv.sky.it/']
  ];
  const RAI_CHANNELS=[['rai-1','Rai 1',1],['rai-2','Rai 2',2],['rai-3','Rai 3',3],['rai-4','Rai 4',21],['rai-movie','Rai Movie',24],['rai-premium','Rai Premium',25],['rai-gulp','Rai Gulp',42],['rai-yoyo','Rai Yoyo',43]];
  const TOAST_MS=3000;
  function toast(msg){let el=byId('toast');el.textContent=msg;el.classList.add('show');clearTimeout(toast.timer);toast.timer=setTimeout(()=>el.classList.remove('show'),TOAST_MS)}
  function openExternal(url){
    try{const u=new URL(url);if(u.protocol!=='https:')throw Error('protocollo non consentito');
      if(isNative)AndroidBridge.openExternal(u.toString());else window.open(u.toString(),'_blank','noopener,noreferrer');
    }catch(e){toast('Collegamento non disponibile')}
  }
  // Cross-origin JSON: Android bridge has explicit HTTPS host allowlist; browser uses CORS when supported.
  let seq=0; const pending=new Map();
  window.AppNative={onResponse(id,status,body){const p=pending.get(id);if(!p)return;pending.delete(id);clearTimeout(p.timeout);
    if(status<200||status>=300){p.reject(new Error(`HTTP ${status}: ${String(body).slice(0,100)}`));return}
    try{p.resolve(JSON.parse(body))}catch(e){p.reject(new Error('Risposta JSON non valida'))}
  }};
  function fetchJson(url){
    if(!isNative)return fetch(url,{cache:'no-store'}).then(async r=>{if(!r.ok)throw Error('HTTP '+r.status);return r.json()});
    return new Promise((resolve,reject)=>{let id=++seq;let timeout=setTimeout(()=>{pending.delete(id);reject(new Error('Timeout della fonte dati'))},17500);
      pending.set(id,{resolve,reject,timeout});try{AndroidBridge.fetchJson(url,id)}catch(e){pending.delete(id);clearTimeout(timeout);reject(e)}
    });
  }
  function saveMeta(){store.set('metadata',metadata)}
  function cachedMeta(type,id){let x=metadata[asset(type,id)];if(!x)return null;let max=x.url?86400000:900000;return Date.now()-x.when<max?x:null}
  function metaValue(type,id){let a=metadata[asset(type,id)];return a&&a.url?a:null}
  function scoreCandidate(a,b){const aa=normTitle(a),bb=normTitle(b);if(!aa||!bb)return 0;if(aa===bb)return 1;
    if(aa.includes(bb)||bb.includes(aa))return .88;
    const aw=new Set(aa.split(' ')),bw=new Set(bb.split(' '));const match=[...aw].filter(s=>bw.has(s)).length;
    return match/Math.max(aw.size,bw.size);
  }
  function imageInfo(item,type){
    const existing=metaValue(type,item.id);return existing?.url||'';
  }
  function posterHtml(item,type,extraClass=''){
    const src=imageInfo(item,type);const key=asset(type,item.id);const label=type==='film'?'Locandina':'Copertina';
    return `<div class="poster-wrap ${extraClass}" data-poster="${safe(key)}">
      ${src?`<img src="${safe(src)}" alt="${label} di ${safe(item.title)}" loading="lazy" onerror="App.imageFailed('${safe(key)}')">`:''}
      <div class="poster-placeholder" ${src?'style="display:none"':''}><span class="symbol">${type==='film'?'🎞':'📚'}</span>${label} ${cachedMeta(type,item.id)?'non disponibile':'in ricerca…'}</div>
      ${type==='film'&&metaValue(type,item.id)?.origin==='Apple iTunes'?`<button class="poster-apple" onclick="App.openArt('film','${item.id}')">Scheda Apple TV ↗</button>`:''}
      </div>`;
  }
  // Image enrichment is intentionally serialized: not 40 network requests at the same time.
  const tasks=[],queued=new Set();let running=0;
  function queueImage(type,item){const key=asset(type,item.id);const c=cachedMeta(type,item.id);if(c){hydrateImage(key);return}
    if(queued.has(key))return;queued.add(key);tasks.push({type,item,key});pumpImages();
  }
  function pumpImages(){while(running<2&&tasks.length){const t=tasks.shift();running++;
      loadImage(t.type,t.item).then(info=>{
        metadata[t.key]={url:info?.url||'',link:info?.link||'',origin:info?.origin||'',when:Date.now()};saveMeta();hydrateImage(t.key);
      }).catch(()=>{metadata[t.key]={url:'',when:Date.now()};saveMeta();hydrateImage(t.key)})
       .finally(()=>{running--;queued.delete(t.key);pumpImages()});
    }}
  function hydrateImage(key){for(const el of document.querySelectorAll('[data-poster]')){
      if(el.getAttribute('data-poster')!==key)continue;
      const [type,id]=key.split(':');let info=metaValue(type,id);let old=el.querySelector('img');let placeholder=el.querySelector('.poster-placeholder');
      if(info?.url){if(!old){old=document.createElement('img');old.loading='lazy';old.alt=`${type==='film'?'Locandina':'Copertina'} originale`;old.onerror=()=>{old.remove();if(placeholder){placeholder.style.display='block';placeholder.innerHTML='<span class="symbol">🎞</span>Immagine non caricabile'}};el.prepend(old)}
        old.src=info.url;placeholder.style.display='none';
        if(type==='film'&&info.origin==='Apple iTunes'&&!el.querySelector('.poster-apple')){
          const button=document.createElement('button');button.className='poster-apple';button.textContent='Scheda Apple TV ↗';button.onclick=()=>window.App.openArt('film',id);el.append(button);
        }
      }
      else if(placeholder){placeholder.style.display='block';placeholder.innerHTML=`<span class="symbol">${type==='film'?'🎞':'📚'}</span> ${type==='film'?'Locandina':'Copertina'} non disponibile`;}
    }}
  async function loadImage(type,item){return type==='film'?loadFilmArt(item):loadBookCover(item)}
  async function loadFilmArt(f){
    // Apple's artwork is displayed only next to the link to the Apple catalog item.
    let terms=[f.original,f.title].filter((x,i,a)=>x&&a.indexOf(x)===i);
    for(const term of terms){
      const url='https://itunes.apple.com/search?'+new URLSearchParams({term,country:'it',media:'movie',entity:'movie',limit:'12'});
      try{const data=await fetchJson(url);let best=null,score=0;
        for(const a of data.results||[]){
          const titleScore=Math.max(scoreCandidate(a.trackName,f.title),scoreCandidate(a.trackName,f.original));
          const year=a.releaseDate?new Date(a.releaseDate).getFullYear():0;
          if(year&&Math.abs(year-f.year)>2)continue;
          if(titleScore>score&&a.artworkUrl100&&a.trackViewUrl){score=titleScore;best=a}
        }
        if(best&&score>=.78)return {url:best.artworkUrl100,link:best.trackViewUrl,origin:'Apple iTunes'};
      }catch(e){}
    }
    return null;
  }
  async function loadBookCover(b){
    try{
      let q=`intitle:${b.title}+inauthor:${b.author}`;
      let url='https://www.googleapis.com/books/v1/volumes?'+new URLSearchParams({q,maxResults:'8',printType:'books'});
      let d=await fetchJson(url);let best=null,high=0;
      for(const v of d.items||[]){let x=v.volumeInfo||{};let titleScore=scoreCandidate(x.title,b.title);
        let authorScore=Math.max(...(x.authors||[]).map(a=>scoreCandidate(a,b.author)),0);
        let s=titleScore*.8+authorScore*.2;
        if(titleScore>=.8&&authorScore>=.5&&s>high&&x.imageLinks?.thumbnail){high=s;best=v}
      }
      if(best&&high>.72){const x=best.volumeInfo;return {url:x.imageLinks.thumbnail.replace(/^http:/,'https:'),link:x.infoLink||'',origin:'Google Books'}};
    }catch(e){}
    try{
      const d=await fetchJson('https://openlibrary.org/search.json?'+new URLSearchParams({title:b.title,author:b.author,limit:'5',fields:'key,title,author_name,cover_i,first_publish_year'}));
      let doc=(d.docs||[]).find(v=>v.cover_i&&scoreCandidate(v.title,b.title)>.8&&
        (v.author_name||[]).some(a=>scoreCandidate(a,b.author)>=.5));
      if(doc)return {url:`https://covers.openlibrary.org/b/id/${doc.cover_i}-M.jpg`,link:`https://openlibrary.org${doc.key?.startsWith('/')?'':'/'}${doc.key}`,origin:'Open Library'};
    }catch(e){}
    return null;
  }
  function prefetchVisible(){
    for(const el of document.querySelectorAll('[data-poster]')){
      const [type,id]=el.getAttribute('data-poster').split(':');const item=(type==='film'?FILMS:BOOKS).find(x=>x.id===id);
      if(item)queueImage(type,item);
    }
  }
  function header(section,sub){return `<div class="page-heading"><div class="eyebrow" style="color:#b07d37">✦ ${safe(sub||'Io Amo la Magia del Natale')}</div><h1>${safe(section)}</h1></div>`}
  function sectionTitle(title,route,caption=''){
    return `<div class="section-title"><div>${caption?`<small>${safe(caption)}</small>`:''}<h2>${safe(title)}</h2></div>${route?`<button onclick="App.go('${route}')">Vedi tutti ›</button>`:''}</div>`;
  }
  function favoriteBtn(type,id){const key=asset(type,id);return `<button class="heart ${favorites.has(key)?'selected':''}" aria-label="${favorites.has(key)?'Togli dai':'Aggiungi ai'} preferiti" onclick="App.toggleFavorite('${type}','${id}')">${favorites.has(key)?'♥':'♡'}</button>`}
  function filmCard(f){return `<article class="media-card">${posterHtml(f,'film')}<div class="media-body">
      <h3>${safe(f.title)}</h3><div class="meta">${f.year} · ${safe(f.genre)}</div>
      <p class="description">${safe(f.synopsis)}</p><div class="card-actions"><button class="link-action" onclick="App.detail('film','${f.id}')">Scopri il film ›</button>${favoriteBtn('film',f.id)}</div></div></article>`}
  function bookCard(b){return `<article class="media-card">${posterHtml(b,'book')}<div class="media-body">
      <h3>${safe(b.title)}</h3><div class="meta">${safe(b.author)}</div><p class="description">${safe(b.synopsis)}</p>
      <div class="card-actions"><button class="link-action" onclick="App.detail('book','${b.id}')">Scopri il libro ›</button>${favoriteBtn('book',b.id)}</div></div></article>`}
  function filmGrid(arr){return `<div class="media-grid">${arr.map(filmCard).join('')}</div>`}
  function bookGrid(arr){return `<div class="media-grid">${arr.map(bookCard).join('')}</div>`}
  function featuredFilm(n=0){return FILMS[(Math.floor(Date.now()/86400000)+n)%FILMS.length]}
  function featuredBook(n=0){return BOOKS[(Math.floor(Date.now()/86400000)+n)%BOOKS.length]}
  function home(){
    const f=featuredFilm(0),b=featuredBook(0),t=state.tv.get(dateKey(inDays(0)));
    const tomorrow=state.tv.get(dateKey(inDays(1)));
    let tvText=t?.events?.length?`${t.events.length} proposte TV verificate`:'Consulta la programmazione ufficiale';
    return `<section class="hero" aria-label="Villaggio natalizio incantato"><div class="hero-content">
      <div><div class="eyebrow">❄ Benvenuti nella magia ✦</div><h1>La Magia<br>del Natale</h1>
      <p>Film, libri e sorprese per vivere ogni giorno un Natale da favola.</p></div>
      <div class="hero-bottom"><button class="soft-pill" onclick="App.go('avvento')">🎁 Apri l'Avvento ›</button><span class="hero-meta">✦ Stelle e neve ✦</span></div>
      </div></section>
      <div class="grid-links">
        <button class="magic-tile" onclick="App.go('film')"><span class="bigicon">🎬</span><strong>Film di Natale</strong><small>Storie da vedere</small></button>
        <button class="magic-tile" onclick="App.go('libri')"><span class="bigicon">📚</span><strong>Libri ed eBook</strong><small>Letture sotto l'albero</small></button>
        <button class="magic-tile" onclick="App.go('tv')"><span class="bigicon">📺</span><strong>Natale in TV</strong><small>${safe(tvText)}</small></button>
        <button class="magic-tile" onclick="App.go('avvento')"><span class="bigicon">🎁</span><strong>Calendario</strong><small>24 sorprese magiche</small></button>
        <button class="magic-tile" onclick="App.go('gratis')"><span class="bigicon">🎥</span><strong>Film gratis</strong><small>Servizi legali da esplorare</small></button>
      </div>
      ${sectionTitle('Il consiglio di oggi','film','✨ Una storia da guardare')}${filmGrid([f])}
      ${sectionTitle('Un libro da scoprire','libri','📖 Una lettura da sogno')}${bookGrid([b])}
      <div class="ice-panel"><h3>📺 Film di oggi e domani</h3>
       <p class="hint">${t?.events?.length?'Oggi: '+t.events.length+' titoli riconosciuti.':'Oggi: apri la guida e verifica le emittenti.'} ${tomorrow?.events?.length?'Domani: '+tomorrow.events.length+' titoli riconosciuti.':'Domani: la disponibilità dei palinsesti dipende dalle emittenti.'}</p>
       <div class="button-row"><button class="primary" onclick="App.go('tv')">Apri la guida TV ›</button><button class="secondary" onclick="App.loadTvFor(1)">Controlla domani</button></div>
      </div>
      ${sectionTitle('Film più recenti','film')}${filmGrid(FILMS.filter(x=>x.year>=2022).sort((a,b)=>b.year-a.year).slice(0,4))}
      ${sectionTitle('Natale in famiglia','film')}${filmGrid(FILMS.filter(x=>x.category==='famiglia').slice(0,4))}
      ${sectionTitle('Natale romantico','film')}${filmGrid(FILMS.filter(x=>x.category==='romantico').slice(0,4))}
      ${sectionTitle('Cartoni e magia','film')}${filmGrid(FILMS.filter(x=>x.category==='animazione').slice(0,4))}
      <div class="ice-panel"><h3>🎥 Film gratuiti, legalmente</h3><p>Scopri le sezioni gratuite dei servizi ufficiali e verifica i titoli disponibili oggi.</p><button class="secondary" onclick="App.go('gratis')">Esplora le piattaforme ›</button></div>
      <div class="ice-panel"><h3>🎁 Il nostro Calendario dell'Avvento</h3><p>Dal 1° al 24 dicembre, una casellina con un film e un libro di Natale, ogni giorno.</p><button class="secondary" onclick="App.go('avvento')">Scopri le caselline ✦</button></div>
      <div class="ad-notice">Pubblicità non attiva in questa versione di prova · nessun annuncio fittizio</div>`;
  }
  function filmPage(){const cats=[['tutti','Tutti'],['famiglia','Famiglia'],['animazione','Animazione'],['romantico','Romantici'],['comico','Da ridere'],['classico','Classici']];
    const arr=FILMS.filter(f=>(state.filmCategory==='tutti'||state.filmCategory===f.category)&&(!state.query||slug(f.title+' '+f.original+' '+f.genre).includes(slug(state.query))));
    return header('Film di Natale','🎬 La magia sullo schermo')+`<p class="hint">${FILMS.length} film selezionati, con trame, preferiti, trailer da cercare e collegamenti per controllare le piattaforme. Le disponibilità non sono inventate.</p>
     <input class="search-input" id="movieSearch" placeholder="Cerca un film, un genere..." value="${safe(state.query)}" aria-label="Cerca film" oninput="App.searchFilm(this.value)">
     <div class="chips">${cats.map(([id,t])=>`<button class="choice ${state.filmCategory===id?'active':''}" onclick="App.filterFilm('${id}')">${t}</button>`).join('')}</div>
     <div id="filmResults"><p class="stat">${arr.length} titoli trovati</p>${arr.length?filmGrid(arr):empty('Nessun film trovato','Prova con un altro titolo o un altro genere.')}</div>`;
  }
  function bookPage(){const cats=[['tutti','Tutti'],['bambini','Bambini'],['classico','Classici'],['fantasia','Fiabe e magia'],['famiglia','Famiglia'],['giallo','Gialli']];
    const arr=BOOKS.filter(b=>(state.bookCategory==='tutti'||state.bookCategory===b.category)&&(!state.query||slug(b.title+' '+b.author).includes(slug(state.query))));
    return header('Libri di Natale','📚 Racconti vicino al camino')+
     `<p class="hint">Libri ed eBook, con copertine editoriali quando i cataloghi restituiscono l'edizione corretta. Link per cercare cartaceo e Kindle su Amazon.it.</p>
     <input class="search-input" id="bookSearch" placeholder="Cerca titolo o autore..." value="${safe(state.query)}" aria-label="Cerca libri" oninput="App.searchBook(this.value)">
     <div class="chips">${cats.map(([id,t])=>`<button class="choice ${state.bookCategory===id?'active':''}" onclick="App.filterBook('${id}')">${t}</button>`).join('')}</div>
     <div id="bookResults"><p class="stat">${arr.length} libri trovati</p>${arr.length?bookGrid(arr):empty('Nessun libro trovato','Cambia i termini di ricerca.')}</div>`;
  }
  function empty(title,description,emoji='❄'){return `<div class="empty-state"><div class="emoji">${emoji}</div><h3>${safe(title)}</h3><p>${safe(description)}</p></div>`}
  function bookAmazonLink(b,kind){
    // No affiliate tracking in the debug APK: Amazon Associates mobile-app approval required.
    const q=`${b.title} ${b.author}`;
    const u=new URL('https://www.amazon.it/s');u.searchParams.set('k',q);u.searchParams.set('i',kind==='kindle'?'digital-text':'stripbooks');
    if(AMAZON_APP_APPROVED)u.searchParams.set('tag',AMAZON_ASSOCIATES_TAG);
    return u.toString();
  }
  function filmDetail(f){let meta=metaValue('film',f.id);
    return `<button class="soft-pill" onclick="App.go('film')">← Torna ai film</button>
      <div class="detail-hero" style="margin-top:14px">${posterHtml(f,'film')}
        <div><h1>${safe(f.title)}</h1><div class="meta">${f.year} · ${safe(f.genre)}</div><p class="hint">${safe(f.original!==f.title?'Titolo originale: '+f.original:'Un film per l’atmosfera delle feste')}</p>${favoriteBtn('film',f.id)}</div>
      </div>
      <div class="details-grid"><div class="ice-panel"><h3>📖 La trama</h3><p>${safe(f.synopsis)}</p>
        <button class="secondary" onclick="App.toggleSeen('${f.id}')">${seen.has(f.id)?'✓ Già visto':'✓ Segna come visto'}</button></div>
      <div class="ice-panel"><h3>🎞 La locandina vera</h3><p class="hint">${meta?'Locandina trovata su '+safe(meta.origin)+'.':'Sto cercando una locandina verificata. Se manca, non mostro immagini di un altro film.'}</p>
       ${meta?.link?`<button class="secondary" onclick="App.openArt('film','${f.id}')">Apri la scheda Apple TV</button>`:''}
       <button class="soft-pill" onclick="App.retryArt('film','${f.id}')">Riprova immagine</button></div></div>
      <div class="ice-panel"><h3>📺 Dove vederlo?</h3>
        <p class="hint">Le piattaforme possono cambiare: apri la ricerca aggiornata prima di abbonarti o noleggiare.</p>
        <div class="button-row"><button class="primary" onclick="App.justWatch('${f.id}')">Verifica streaming ›</button>
        <button class="secondary" onclick="App.searchTrailer('${f.id}')">Cerca trailer ufficiale ▷</button></div>
        <div class="source-links" style="margin-top:10px"><button class="soft-pill" onclick="App.streaming('netflix','${f.id}')">Cerca su Netflix</button><button class="soft-pill" onclick="App.streaming('disney','${f.id}')">Apri Disney+</button><button class="soft-pill" onclick="App.streaming('prime','${f.id}')">Apri Prime Video</button><button class="soft-pill" onclick="App.streaming('apple','${f.id}')">Apri Apple TV</button></div></div>
      <div class="ice-panel"><h3>🎄 Un film per l’Avvento</h3><p>Salvalo tra i preferiti e ritrovalo quando vuoi.</p></div>`;
  }
  function bookDetail(b){let meta=metaValue('book',b.id);
    return `<button class="soft-pill" onclick="App.go('libri')">← Torna ai libri</button><div class="detail-hero" style="margin-top:14px">
    ${posterHtml(b,'book')}<div><h1>${safe(b.title)}</h1><div class="meta">${safe(b.author)}</div><p class="hint">${safe(b.category)}</p>${favoriteBtn('book',b.id)}</div></div>
    <div class="ice-panel"><h3>📖 Di cosa parla</h3><p>${safe(b.synopsis)}</p>
    <p class="hint">${meta?'Copertina rilevata da '+safe(meta.origin)+'.':'Cerco l’edizione corretta; nessuna copertina inventata.'}</p>
    <button class="soft-pill" onclick="App.retryArt('book','${b.id}')">Aggiorna copertina</button>
    ${meta?.link?`<button class="secondary" onclick="App.openArt('book','${b.id}')">Scheda del catalogo</button>`:''}</div>
    <div class="ice-panel"><h3>🎁 Scegli la tua edizione</h3><p class="hint">Le edizioni Kindle e cartacee sono ricerche distinte: la disponibilità effettiva va verificata su Amazon.</p>
      <div class="book-links"><button class="primary" onclick="App.amazon('${b.id}','paper')">Libro cartaceo</button>
      <button class="secondary" onclick="App.amazon('${b.id}','kindle')">eBook Kindle</button></div>
      <p class="hint">Codice Affiliati predisposto, non attivato nell'APK finché l'app non sarà approvata da Amazon Associates.</p></div>`;
  }
  function tvSources(){return `<div class="source-links">${OPEN_SOURCE_TV.map(([name,url],i)=>`<button class="secondary" onclick="App.openSource(${i})">${safe(name)} ↗</button>`).join('')}</div>`}
  const isChristmas=name=>{
    let x=slug(name);
    if(FILMS.some(f=>scoreCandidate(name,f.title)>.86||scoreCandidate(name,f.original)>.86))return true;
    return /natale|christmas|babbo natale|santa claus|santa clause|grinch|noel|schiaccianoci|polar express|home alone|vacanze di natale|wonderful life|elfo|elf\b/.test(x);
  };
  function parseRai(data,ch,date){
    let arr=Array.isArray(data?.events)?data.events:null;
    if(!arr&&Array.isArray(data?.programs))arr=data.programs;
    if(!arr&&Array.isArray(data?.programmi))arr=data.programmi;
    if(!arr)return null;
    let seenTitles=new Set(),out=[];
    for(const v of arr){
      let title=String(v.name||v.title||v.titolo||'').trim();
      let time=String(v.hour||v.timePublished||v.start||v.startTime||'');
      let hhmm=(time.match(/(?:^|T|\s)(\d{1,2}):(\d{2})/)||[]);
      if(!title||!hhmm.length)continue;
      const hour=pad(+hhmm[1])+':'+hhmm[2];if(+hhmm[1]>23)continue;
      let k=title+'-'+hour+'-'+ch[0];if(seenTitles.has(k))continue;seenTitles.add(k);
      let genre=String(v.genre||v.type||v.tipologia||'');
      out.push({title,channel:ch[1],number:ch[2],hour,genre,isChristmas:isChristmas(title),date,source:'RaiPlay'});
    }
    return out;
  }
  async function loadTV(index,force=false){
    const key=dateKey(inDays(index));const prev=state.tv.get(key);
    if(!force&&prev?.loading)return;
    if(!force&&prev&&Date.now()-prev.at<1000*60*30)return;
    state.tv.set(key,{loading:true,events:prev?.events||[],at:Date.now(),ok:0,errors:[],sources:[]});
    if(state.route==='tv')render(false);
    let events=[],good=0,errors=[];const dd=inDays(index);let date=pad(dd.getDate())+'-'+pad(dd.getMonth()+1)+'-'+dd.getFullYear();
    // 8 canali ufficiali; no fake TV8 or Sky programming. Tested format: {events:[{name,hour}]}.
    for(let k=0;k<RAI_CHANNELS.length;k+=4){
      const batch=RAI_CHANNELS.slice(k,k+4);
      await Promise.all(batch.map(async ch=>{
        let url=`https://www.raiplay.it/palinsesto/app/${ch[0]}/${date}.json`;
        try{
          let raw=await fetchJson(url);const parsed=parseRai(raw,ch,key);
          if(parsed===null)throw Error('Formato palinsesto non riconosciuto');
          good++;events.push(...parsed);
        }catch(err){errors.push(`${ch[1]}: ${String(err.message||err).slice(0,65)}`)}
      }));
      const obj=state.tv.get(key);if(obj){obj.events=events.slice().sort((a,b)=>a.hour.localeCompare(b.hour));obj.ok=good;obj.errors=errors.slice();obj.sources=good?['RaiPlay']:[];obj.at=Date.now()}
      if(state.route==='tv'&&state.dateIndex===index)render(false);
    }
    state.tv.set(key,{loading:false,events:events.sort((a,b)=>a.hour.localeCompare(b.hour)),at:Date.now(),ok:good,errors,sources:good?['RaiPlay']:[]});
    if(state.route==='tv'&&state.dateIndex===index)render(false);
    if(state.route==='home')render(false);
  }
  function tvPage(){
    const key=dateKey(inDays(state.dateIndex)),d=state.tv.get(key);
    const all=d?.events||[],filtered=state.tvOnlyChristmas?all.filter(x=>x.isChristmas):all;
    let status = '';
    if(!d)status='<div class="status">Premi «Aggiorna» per leggere la guida ufficiale RaiPlay. Le altre emittenti sono consultabili dai loro siti.</div>';
    else if(d.loading)status=`<div class="status">⏳ Caricamento in corso… ricevuti ${d.ok} canali su ${RAI_CHANNELS.length}. ${d.errors.length?'Alcune fonti non rispondono.':''}</div>`;
    else if(d.ok===0)status='<div class="status error">⚠ Impossibile leggere la guida RaiPlay per questa data. Nessun orario viene inventato. Apri una delle guide ufficiali qui sotto.</div>';
    else status=`<div class="status">✓ Guida letta da ${d.ok} canali Rai su ${RAI_CHANNELS.length} · ${all.length} programmi · controllata alle ${new Date(d.at).toLocaleTimeString('it-IT',{hour:'2-digit',minute:'2-digit'})}. <br>Le altre emittenti non sono comprese in questo feed.</div>`;
    return header('Guida TV','📺 Il Natale sul piccolo schermo')+
      `<p class="hint">Seleziona il giorno. Canali, date e orari compaiono soltanto quando sono realmente restituiti dalla fonte.</p>
      <div class="chips">${Array.from({length:7},(_,i)=>`<button class="choice day-chip ${state.dateIndex===i?'active':''}" onclick="App.selectDay(${i})">${safe(displayDay(i))}<small>${pad(inDays(i).getDate())}/${pad(inDays(i).getMonth()+1)}</small></button>`).join('')}</div>
      <div class="tv-summary"><div class="button-row"><button class="primary" onclick="App.reloadTv()">↻ Aggiorna ${state.dateIndex===0?'oggi':prettyDate(key)}</button></div></div>
      ${status}
      <div class="chips" style="margin-top:13px">
      <button class="choice ${state.tvOnlyChristmas?'active':''}" onclick="App.tvFilter(true)">🎄 Film natalizi</button>
      <button class="choice ${!state.tvOnlyChristmas?'active':''}" onclick="App.tvFilter(false)">📋 Tutti i programmi Rai</button></div>
      ${filtered.length?`<p class="stat">${filtered.length} programmi visualizzati · ${safe(prettyDate(key))}</p>${filtered.slice(0,150).map(tvRow).join('')}`:
        empty(d?.loading?'Sto leggendo i palinsesti…':d?.ok?'Nessun film natalizio riconosciuto':'Nessun dato TV confermato',d?.ok?'Nei canali letti non risultano film natalizi identificabili per questa data. Puoi consultare tutti i programmi Rai o la guida completa dei canali.':'Riprova più tardi o consulta direttamente le emittenti.','📡')}
      <div class="ice-panel"><h3>📡 Altre guide ufficiali</h3><p class="hint">TV8, Mediaset e Sky: la copertura integrata richiede l'accesso autorizzato ai rispettivi dati. Apri la loro guida e scegli la data ${safe(prettyDate(key))}.</p>${tvSources()}</div>
      ${d?.errors?.length?`<details class="ice-panel"><summary>Dettagli tecnici (${d.errors.length} problemi)</summary><p class="hint">${safe(d.errors.slice(0,8).join(' · '))}</p></details>`:''}
      <div class="notice">Le guide possono cambiare all'ultimo momento. Gli orari sono visualizzati nel fuso italiano del dispositivo. Nessuna diretta video è riprodotta senza autorizzazione.</div>`;
  }
  function tvRow(v){
    const start=new Date(`${v.date}T${v.hour}:00`).getTime();const canRemind=start>Date.now()+30*60000;const encodedTitle=encodeURIComponent(v.title).replace(/'/g,'%27');
    const f=FILMS.find(x=>scoreCandidate(x.title,v.title)>.90||scoreCandidate(x.original,v.title)>.90);
    return `<article class="tv-row"><div><div class="time">${safe(v.hour)}</div><div class="channel">${safe(v.channel)}${v.number?' · '+v.number:''}</div></div>
      <div><h3>${safe(v.title)}</h3><p class="hint">${safe(v.genre||'Programma TV')} · ${safe(v.source)} · ${safe(prettyDate(v.date))}</p>
      <div class="button-row">${f?`<button class="secondary" onclick="App.detail('film','${f.id}')">Scheda film</button>`:''}
      ${canRemind?`<button class="soft-pill" onclick="App.remind('${safe(v.date)}','${safe(v.hour)}',decodeURIComponent('${encodedTitle}'))">🔔 Avvisami</button>`:''}
      </div></div></article>`;
  }
  function adventPage(){
    const d=new Date();const unlocked=n=>state.adventPreview||(d.getMonth()===11&&d.getDate()>=n);
    const count=ADVENT.filter(a=>unlocked(a.day)).length;
    return header('Calendario dell’Avvento','🎁 24 giorni di magia')+
      `<div class="advent-cover" role="img" aria-label="Villaggio innevato e luminoso"></div>
      <div class="ice-panel"><h3>🎄 Una sorpresa ogni giorno</h3><p>Apri la casellina del giorno: troverai <strong>un film e un libro di Natale</strong>.</p>
      <p class="hint">${d.getMonth()===11?`${count} caselline disponibili oggi.`:'Le caselline si aprono dal 1° al 24 dicembre.'}</p>
      ${state.adventPreview?'<span class="ribbon">MODALITÀ ANTEPRIMA · Le sorprese sono visibili per prova</span>':''}</div>
      <div class="calendar">${ADVENT.map(a=>`<button class="${unlocked(a.day)?'open':'locked'}" onclick="App.openDay(${a.day})" aria-label="Casellina ${a.day}${unlocked(a.day)?' aperta':' bloccata'}">
        <span>${a.day}</span><small>${unlocked(a.day)?'🎁 Apri':'🔒 In attesa'}</small></button>`).join('')}</div>
      <div class="ice-panel"><h3>✨ La magia del 25 dicembre</h3><p>Un augurio speciale apparirà il giorno di Natale.</p>
      ${d.getMonth()===11&&d.getDate()>=25?`<p class="big-note">Buon Natale! Che la bellezza di ogni piccola cosa illumini la tua casa. ❄️💙</p>`:''}</div>`;
  }
  function adventDetail(n){
    let e=ADVENT.find(x=>x.day===n);if(!e)return empty('Casellina non trovata','Ritorna al calendario.');
    let f=FILMS.find(x=>x.id===e.filmId), b=BOOKS.find(x=>x.id===e.bookId);
    let d=new Date(),open=state.adventPreview||(d.getMonth()===11&&d.getDate()>=n);
    if(!open)return header('Un po’ di pazienza…','🔒 La casellina è ancora chiusa')+empty('La magia arriva al momento giusto',`Questa casellina si apre il ${n} dicembre.`, '🎁')+`<button class="secondary" onclick="App.go('avvento')">Torna al calendario</button>`;
    return header(`Il dono del giorno ${n}`,'✦ Calendario dell’Avvento')+
      `<div class="big-note">${safe(e.message)} ✨</div>
       ${sectionTitle('Il film della casellina',null,'🎬 Stasera si guarda...')}${filmGrid([f])}
       ${sectionTitle('Il libro della casellina',null,'📚 Leggiamo insieme...')}${bookGrid([b])}
       <div class="ice-panel"><button class="secondary" onclick="App.go('avvento')">← Torna alle 24 caselline</button></div>`;
  }
  function favoritesPage(){
    const f=FILMS.filter(x=>favorites.has(asset('film',x.id))),b=BOOKS.filter(x=>favorites.has(asset('book',x.id)));
    const seenFilms=FILMS.filter(x=>seen.has(x.id));
    return header('I tuoi preferiti','♡ La mia scatola dei ricordi')+
      `<div class="ice-panel"><h3>Le storie che ami</h3><p class="hint">Preferiti e film già visti sono salvati su questo telefono. Non serve creare un account.</p></div>
      ${sectionTitle(`Film preferiti (${f.length})`,null)}${f.length?filmGrid(f):empty('Non hai ancora film preferiti','Tocca il cuore sulle schede dei film.')}
      ${sectionTitle(`Libri preferiti (${b.length})`,null)}${b.length?bookGrid(b):empty('Non hai ancora libri preferiti','Tocca il cuore sulle schede dei libri.')}
      ${sectionTitle(`Film già visti (${seenFilms.length})`,null)}${seenFilms.length?filmGrid(seenFilms):'<p class="hint">Segna i film già visti nella loro scheda.</p>'}
      <div class="ice-panel"><h3>⚙ Preferenze e informazioni</h3><div class="profile-row"><span>Anteprima dell'Avvento</span><button class="choice" onclick="App.togglePreview()">${state.adventPreview?'Disattiva':'Attiva prova'}</button></div>
       <p class="hint">In modalità prova puoi aprire le caselline anche fuori dicembre. I dati non cambiano.</p>
       <div class="profile-row"><span>Origine dei contenuti</span><span>RaiPlay / cataloghi editoriali</span></div>
       <p class="hint">I poster dei film da Apple sono associati al collegamento verso la relativa scheda Apple; le copertine dei libri vengono dai cataloghi Google Books e Open Library.</p>
       <div class="profile-row"><span>Pubblicità</span><span>Non attiva</span></div>
       <p class="hint">Per attivare annunci serviranno AdMob, consenso privacy e documentazione legale.</p>
       <div class="profile-row"><span>Affiliazione Amazon</span><span>In attesa di approvazione app</span></div>
       <p class="hint">Il codice monyka87-21 è predisposto per quando la distribuzione dell’app sarà autorizzata dal programma Associates.</p>
       <button class="secondary" onclick="App.openWebsite()">Visita Io Amo la Magia del Natale ↗</button></div>`;
  }
  function gratisPage(){
    const sources=[
      ['RaiPlay','https://www.raiplay.it/','Film e programmi disponibili sul portale pubblico'],
      ['Mediaset Infinity','https://mediasetinfinity.mediaset.it/','Contenuti gratuiti e con abbonamento: verifica la scheda'],
      ['Pluto TV','https://pluto.tv/it/','Canali e contenuti gratuiti supportati da pubblicità'],
      ['YouTube','https://www.youtube.com/','Cerca i contenuti pubblicati dai canali ufficiali']
    ];
    return header('Film da vedere gratis','🎥 Piattaforme legali')+
      `<div class="ice-panel"><h3>🎄 Un Natale da guardare</h3><p>Qui non segnaliamo come «gratis» un titolo senza averlo verificato. Puoi però esplorare le piattaforme autorizzate e cercare i film natalizi disponibili.</p></div>
       ${sources.map(([name,url,desc],i)=>`<div class="ice-panel"><h3>${safe(name)}</h3><p>${safe(desc)}</p><button class="secondary" onclick="App.openFree(${i})">Apri ${safe(name)} ↗</button></div>`).join('')}
       <div class="notice">Disponibilità e condizioni di visione possono cambiare. Non ospitiamo video protetti né streaming non autorizzati.</div>`;
  }
  function searchPage(){
    const q=state.query.trim();let f=q?FILMS.filter(x=>slug(x.title+' '+x.original+' '+x.genre).includes(slug(q))):FILMS.slice(0,6);
    let b=q?BOOKS.filter(x=>slug(x.title+' '+x.author).includes(slug(q))):BOOKS.slice(0,4);
    return header('Cerca','🔍 Tutte le storie di Natale')+
      `<input class="search-input" id="globalSearch" placeholder="Film, libro, autore..." value="${safe(state.query)}" oninput="App.searchGlobal(this.value)" aria-label="Ricerca generale">
       <div id="globalResults">${searchResults(f,b)}</div>`;
  }
  function searchResults(f,b){return `${sectionTitle(`Film (${f.length})`,null)}${f.length?filmGrid(f):'<p class="hint">Nessun film corrispondente.</p>'}
       ${sectionTitle(`Libri (${b.length})`,null)}${b.length?bookGrid(b):'<p class="hint">Nessun libro corrispondente.</p>'}`}
  function render(scroll=true){
    const routes={home,film:filmPage,libri:bookPage,tv:tvPage,avvento:adventPage,preferiti:favoritesPage,cerca:searchPage,gratis:gratisPage};
    let content='';
    if(state.route==='detail'){
      const [type,id]=state.detail||[]; const item=(type==='film'?FILMS:BOOKS).find(x=>x.id===id);
      content=item?(type==='film'?filmDetail(item):bookDetail(item)):empty('Scheda non disponibile','Torna al catalogo.');
    }else if(state.route==='advent-detail')content=adventDetail(state.detail);
    else content=(routes[state.route]||home)();
    byId('app').innerHTML=content;
    document.querySelectorAll('.tabbar [data-route]').forEach(btn=>btn.classList.toggle('active',btn.getAttribute('data-route')===state.route));
    if(scroll)window.scrollTo(0,0);
    // Start enrichment only for visible card elements (plus next few rows).
    setTimeout(()=>{
      let cards=[...document.querySelectorAll('[data-poster]')];
      for(const el of cards.slice(0,8)){const [type,id]=el.dataset.poster.split(':');let item=(type==='film'?FILMS:BOOKS).find(x=>x.id===id);if(item)queueImage(type,item)}
      if('IntersectionObserver' in window){
        const observer=new IntersectionObserver(entries=>{for(const entry of entries){if(entry.isIntersecting){const [type,id]=entry.target.dataset.poster.split(':');const item=(type==='film'?FILMS:BOOKS).find(x=>x.id===id);if(item)queueImage(type,item);observer.unobserve(entry.target)}}},{rootMargin:'180px'});
        cards.slice(8).forEach(el=>observer.observe(el));
      }
    },0);
  }
  function rerenderSearch(type){
    if(type==='film'){let a=FILMS.filter(f=>(state.filmCategory==='tutti'||f.category===state.filmCategory)&&(!state.query||slug(f.title+' '+f.original+' '+f.genre).includes(slug(state.query))));
      let el=byId('filmResults');if(el){el.innerHTML=`<p class="stat">${a.length} titoli trovati</p>${a.length?filmGrid(a):empty('Nessun film trovato','Prova un altro titolo.')}`;prefetchVisible()};return;
    }
    if(type==='book'){let a=BOOKS.filter(b=>(state.bookCategory==='tutti'||b.category===state.bookCategory)&&(!state.query||slug(b.title+' '+b.author).includes(slug(state.query))));
      let el=byId('bookResults');if(el){el.innerHTML=`<p class="stat">${a.length} libri trovati</p>${a.length?bookGrid(a):empty('Nessun libro trovato','Prova un altro titolo.')}`;prefetchVisible()};return;
    }
    let q=slug(state.query),f=q?FILMS.filter(x=>slug(x.title+' '+x.original+' '+x.genre).includes(q)):FILMS.slice(0,6);
    let b=q?BOOKS.filter(x=>slug(x.title+' '+x.author).includes(q)):BOOKS.slice(0,4);
    if(byId('globalResults')){byId('globalResults').innerHTML=searchResults(f,b);prefetchVisible()}
  }
  // Minimal global API: every button has a functioning handler.
  window.App={
    go(route){state.route=route;state.detail=null;state.query='';render();if(route==='tv')loadTV(state.dateIndex)},
    goBack(){if(state.route==='detail')this.go(state.detail?.[0]==='book'?'libri':'film');else if(state.route==='advent-detail')this.go('avvento');else this.go('home')},
    detail(type,id){state.route='detail';state.detail=[type,id];render()},
    openDay(n){state.route='advent-detail';state.detail=n;render()},
    toggleFavorite(type,id){let k=asset(type,id);favorites.has(k)?favorites.delete(k):favorites.add(k);store.set('favorites',[...favorites]);render(false);toast(favorites.has(k)?'Aggiunto ai preferiti ♥':'Rimosso dai preferiti')},
    toggleSeen(id){seen.has(id)?seen.delete(id):seen.add(id);store.set('seen',[...seen]);render(false);toast('Film già visti aggiornati')},
    togglePreview(){state.adventPreview=!state.adventPreview;store.set('previewAdvent',state.adventPreview);render(false)},
    filterFilm(cat){state.filmCategory=cat;render(false)},filterBook(cat){state.bookCategory=cat;render(false)},
    searchFilm(q){state.query=q;rerenderSearch('film')},searchBook(q){state.query=q;rerenderSearch('book')},searchGlobal(q){state.query=q;rerenderSearch('global')},
    selectDay(n){state.dateIndex=n;render(false);loadTV(n)},tvFilter(v){state.tvOnlyChristmas=v;render(false)},reloadTv(){loadTV(state.dateIndex,true)},
    loadTvFor(n){state.dateIndex=n;this.go('tv');loadTV(n)},
    openSource(i){let el=OPEN_SOURCE_TV[i];if(el)openExternal(el[1])},
    openWebsite(){openExternal('https://ioamolamagiadelnatale.altervista.org/')},
    openFree(i){const urls=['https://www.raiplay.it/','https://mediasetinfinity.mediaset.it/','https://pluto.tv/it/','https://www.youtube.com/'];if(urls[i])openExternal(urls[i])},
    streaming(provider,id){const f=FILMS.find(x=>x.id===id);if(!f)return;const url={
      netflix:'https://www.netflix.com/search?q='+encodeURIComponent(f.title),
      disney:'https://www.disneyplus.com/',prime:'https://www.primevideo.com/',apple:'https://tv.apple.com/it'
    }[provider];if(url)openExternal(url)},
    justWatch(id){let f=FILMS.find(x=>x.id===id);if(f)openExternal('https://www.justwatch.com/it/ricerca?q='+encodeURIComponent(f.title))},
    searchTrailer(id){let f=FILMS.find(x=>x.id===id);if(f)openExternal('https://www.youtube.com/results?search_query='+encodeURIComponent(f.original+' '+f.year+' trailer ufficiale'))},
    amazon(id,kind){let b=BOOKS.find(x=>x.id===id);if(b)openExternal(bookAmazonLink(b,kind))},
    openArt(type,id){let d=metaValue(type,id);if(d?.link)openExternal(d.link)},
    imageFailed(key){let [type,id]=key.split(':');metadata[key]={url:'',when:Date.now()};saveMeta();hydrateImage(key)},
    retryArt(type,id){const key=asset(type,id);delete metadata[key];saveMeta();let x=(type==='film'?FILMS:BOOKS).find(x=>x.id===id);if(x){queueImage(type,x);toast('Ricerca avviata. Verifico il titolo e l’edizione.')}},
    remind(date,hour,title){let ms=new Date(`${date}T${hour}:00`).getTime()-30*60000;if(!isNative){toast('Promemoria attivabili nell’APK Android.');return}
      if(!Number.isFinite(ms)||ms<Date.now()){toast('È troppo tardi per il promemoria di questo film.');return}
      AndroidBridge.remind(title,ms)
    }
  };
  render();
})();
