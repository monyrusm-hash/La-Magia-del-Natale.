# Io Amo la Magia del Natale — progetto Android V16

**Stato: progetto Android di test, non APK compilato e non release commerciale.**

## Cosa c'è

- Home natalizia azzurra originale con consigli e sezioni cinematografiche.
- 34 schede film con trama, indicazione orientativa delle piattaforme, ricerca, preferiti e collegamenti al trailer.
- 16 schede libri e Kindle con ricerca per autore e titolo, link Amazon.it; il tag affiliato non è attivo nell'APK finché non viene autorizzato specificamente da Amazon.
- Calendario dell'Avvento con 24 caselline e proposta film/libro quotidiana.
- Guida TV con 7 date selezionabili; in **build DEBUG** lettura sperimentale per data dei palinsesti dei canali Rai pubblicati da RaiPlay, visualizzazione progressiva oggi/domani e altri giorni, canale e orario, dettagli e promemoria.
- Cache locale delle immagini, con tentativi di ricerca per ID IMDb, titolo/anno, titolo/autore. Le copertine editoriali e le locandine ufficiali sono caricate **solo se abbinate** ai titoli e se il provider le restituisce: non sono incluse nel pacchetto.
- Punti UI per pubblicità. **Nessun annuncio AdMob attivo**.

## Compilazione

Aprire questa cartella in Android Studio con Android SDK 35, Gradle 8.10.2 e JDK 17. Compilare la variante `debug` (`assembleDebug`). La compilazione non è stata eseguita in questo ambiente perché non c'è Android SDK; non dichiarare riuscito un APK senza compilazione reale.

Se si usa Codex, caricare questo ZIP sul repository e inviare il contenuto del file `ISTRUZIONI_CODEX_V16.txt`. Non occorre configurare GitHub Actions per la prima prova.

## Guida TV e limiti importanti

La modalità debug prova le API RaiPlay per giorno su 8 canali Rai; se non riceve dati può tentare un feed XMLTV pubblico **esclusivamente per prove personali**. Alcuni giorni futuri potrebbero non essere ancora pubblicati: l'app distingue la **copertura effettiva** da una data senza programmi natalizi riconosciuti. TV8, Sky, tutte le reti Mediaset e le immagini dei programmi non sono garantite da RaiPlay. Le API pubblicamente accessibili non equivalgono a licenza commerciale. In una build non debug occorre configurare un provider autorizzato tramite `app/src/main/assets/tv-provider.json` con `rightsConfirmed:true`, `feedUrl:https://...`, e un JSON in formato `channels[]`, `shows[]`.

Schema di input del provider commerciale: `{"provider":"Nome","generatedAt":"2026-11-20T00:00:00Z","channels":[{"id":"rai-1","name":"Rai 1","number":"1"}],"shows":[{"channelId":"rai-1","title":"Titolo reale","category":"Film","desc":"...","start":"2026-11-20T20:30:00+01:00","end":"2026-11-20T22:00:00+01:00"}]}`. Questo JSON è un **esempio tecnico**, non una programmazione reale.

Non pubblicare o monetizzare l'app con feed TV o poster di terzi senza verificare permessi, licenze, privacy e uso di API. Le piattaforme streaming riportate nel catalogo sono indicazioni editoriali, non disponibilità live. Le immagini vengono cercate dinamicamente e possono mancare.

## Test eseguiti

Il codice JavaScript passa `node --check`. Test browser automatici: apertura Home, 34 film, 16 libri, 24 porte Avvento, 7 selettori di date TV, programma campione per domani con orario e canale, scheda dettagliata, nessun errore JavaScript. **I dati della verifica di domani sono simulati e non confermano il collegamento reale delle fonti.** Non è stato eseguito un test Android su smartphone.

La firma APK debug potrebbe cambiare tra compilatori, quindi **non disinstallare** la vecchia app senza prima esportare o annotare i preferiti.
