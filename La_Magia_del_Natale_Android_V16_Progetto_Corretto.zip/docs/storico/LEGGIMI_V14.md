# Io Amo la Magia del Natale — Versione 14 (intervento tecnico)

La V14 aggiorna realmente i sorgenti Android della V13. Non contiene un nuovo APK: il pacchetto va compilato.

## Modifiche realizzate

1. **Locandine e copertine**: il bridge nativo scarica un'immagine nel disco privato e la restituisce alla WebView tramite un URL `data:image/...;base64` (anziché HTTPS verso `natale.assets.local`). Ciò elimina una dipendenza dalla risoluzione del dominio fittizio. Il browser non salva grandi immagini base64 in localStorage. Timeout di richiesta di 25 secondi. Ricerca tramite titolo/anno/IMDb per i film e titolo/autore per i libri. Nessuna immagine inventata quando manca il risultato.
2. **Guida TV**: rimosse dal percorso in uso le vecchie fonti TvIt (dati vecchi di mesi) e XMLTV.live (termini vietano l'uso in app commerciali senza autorizzazione). Il progetto è pronto per un **endpoint HTTPS di un fornitore con licenza commerciale**. Dati privi di date valide vengono ignorati. Sorgente non configurata => errore esplicito, non programma inventato.
3. **Home**: mostra esplicitamente l'errore della guida invece di suggerire che sia aggiornata. Preferiti e Calendario dell'Avvento rimangono intatti. Le schede locali dei film e dei libri restano consultabili anche offline.
4. **Versioning**: versionCode 14, cache nomi v14 per non riusare ricerche fallite delle versioni precedenti.

## Per abilitare la guida TV in-app (necessario)

Il file `app/src/main/assets/tv-provider.json` inizialmente contiene `rightsConfirmed:false` e `feedUrl:""`. Per usare un fornitore:

- ottenere da un fornitore EPG un **accordo che autorizzi la visualizzazione in app commerciale**, con i canali e le date richieste;
- creare un backend HTTPS di proprietà che restituisca dati normalizzati come nell'esempio `provider-example.json` (non mettere chiavi API dentro l'APK);
- inserire nel file `tv-provider.json` l'URL HTTPS del proprio backend e `rightsConfirmed:true` **solo dopo l'autorizzazione**;
- ricompilare l'APK e provarlo sul Samsung.

Il feed deve essere JSON, nel formato:

```
{"provider":"Fornitore autorizzato","generatedAt":"2026-11-20T10:00:00Z",
 "channels":[{"id":"tv8","name":"TV8","number":8}],
 "shows":[{"title":"Titolo reale","desc":"Trama","start":"2026-11-21T15:40:00+01:00","end":"2026-11-21T17:20:00+01:00","category":"Film","channelId":"tv8"}]}
```

La disponibilità di 7–14 giorni dipende dal contratto scelto: non è un'opzione grafica. Gracenote dichiara supporto fino a 14 giorni; GuidaTV.uno offre un'interfaccia API con chiave per partner. Le condizioni specifiche devono essere confermate direttamente dai fornitori.

## Copertine e uso commerciale

Le ricerche tramite Apple/iTunes, Cinemeta, Google Books e Open Library sono ancora dinamiche: non garantiscono tutte le edizioni e non conferiscono automaticamente diritti commerciali sulle immagini. Per la pubblicazione con pubblicità (AdMob) serve verificare licenze, attribution e privacy. La V14 non attiva annunci reali, non inserisce chiavi API segrete e non abilita l'affiliazione Amazon dentro l'APK senza approvazione.

## Verifiche richieste a Codex

- `gradle assembleDebug` usando Android SDK 35 (oppure il comando corrispondente);
- controllo permesso INTERNET, WebView, recupero di copertine, validazione di titolo e autore;
- test di caricamento immagini su un vero dispositivo, non soltanto in browser;
- test JSON con provider di prova in ambiente separato, poi provider commerciale configurato;
- test di notifiche e preferiti prima di aggiornare l'app installata, mantenendo la firma di debug se possibile.

**Stato alla consegna:** sintassi JS e struttura ZIP controllate; APK e connessioni su Samsung non verificati. Senza endpoint autorizzato la guida TV integrata è intenzionalmente non disponibile, mentre i collegamenti alla guida esterna restano accessibili.
