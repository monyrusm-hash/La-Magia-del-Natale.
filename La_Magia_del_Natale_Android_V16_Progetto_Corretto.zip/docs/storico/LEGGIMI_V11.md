# Io Amo la Magia del Natale · Versione 11 (test)

## Correzioni rispetto alla V10
- Guida TV: aggiunta fonte aggregata XMLTV.live Italia (circa 262 canali dichiarati).
  Restano TvIt e XMLTV per singoli canali; la copertura reale viene letta dal programma, mai presunta.
- XMLTV nazionale compresso letto via SAX streaming in Java Android per evitare consumo eccessivo di RAM; download limitato.
- Locandine: Cinemeta come primo tentativo per film delle piattaforme streaming, Apple iTunes come alternativa.
  Prima di mostrare un'immagine si confrontano titolo e anno; URL effettivamente verificato.
- Libri: Google Books e Open Library; ricerca manuale ripetibile premendo “Ricarica copertine originali”.
- Cache immagini negativa ridotta a 15 minuti; nuova chiave per non riusare fallimenti V10.
- Bug formato data: ora la data viene composta da Intl.DateTimeFormat.formatToParts per evitare formati locali ambigui.
- Preservato archivio preferiti v5, Calendario dell'Avvento e grafica azzurra approvata.

## Stato dei test
Test JavaScript in Chromium con risposte simulate: guida futuri e poster. Test HTML locale con `node --check`.
**Non eseguiti**: compilazione APK con Android SDK, test fisico su Samsung, richieste live ai servizi esterni.
Queste funzioni richiedono build in Codex e prova sul telefono. Un palinsesto non pubblicato non si può ricostruire.

## Importante su diritti e pubblicità
Questa versione è un prototipo per test. Prima della distribuzione **commerciale** verificare licenze e permessi di uso di tutte le fonti TV (TvIt, Cristian Livella, XMLTV.live) e delle locandine (Cinemeta/Apple) e copertine (Google Books/Open Library). Alcuni cataloghi sono solo per usi non commerciali o subordinati ad accordi.
Non attivare AdMob o affiliazione nell'APK finché non sono rispettati contratti, consenso e approvazioni.

## Compilazione
Aprire la cartella radice in Android Studio oppure in Codex: `gradle --no-daemon assembleDebug` (JDK 17, SDK 35, Gradle 8.10.2). Il debug APK si trova in `app/build/outputs/apk/debug/app-debug.apk`.
