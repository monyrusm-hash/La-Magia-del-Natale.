# Io Amo la Magia del Natale — V15 (prova Android, 20 novembre 2026)

## Cosa è cambiato DAVVERO

### Guida TV
La V14 aveva `feedUrl` vuoto: nessun canale poteva aggiornarsi. In questa V15 la **build DEBUG** prova a interrogare in parallelo 12 guide XMLTV italiane, relative a Rai 1/2/3/4, Rai Movie, Rai Premium, Canale 5, Italia 1, Rete 4, Iris, La5 e Italia 2. Non esiste un palinsesto interno inventato. La fonte dichiara sette giorni di programmi, ma la copertura varia: la V15 conta le date realmente presenti in ogni feed e distingue **guida pubblicata** da **nessun film natalizio riconosciuto**. È disponibile anche il filtro «Tutti i film trovati».

**Fonte pubblica utilizzata unicamente per prova personale:** https://cristianlivella.com/xmltv/ . Non ne è stata verificata l'autorizzazione per app commerciali. Le release NON usano questa fonte automaticamente. Per monetizzare occorre ottenere una licenza per guida TV e collegare `app/src/main/assets/tv-provider.json` a un feed HTTPS autorizzato, che restituisca il JSON nella struttura già usata dall'app. Evitare di inserire credenziali segrete nell'APK.

### Copertine e locandine
- Ricerche Android limitate: per film prima ID IMDb (quando presente) tramite catalogo Cinemeta, poi nome/anno e in alternativa Apple; per libri Open Library con titolo/autore e fallback Google Books.
- Richieste distribuite su 5 thread, fino a 5 alla volta dall'interfaccia. Non congelare copertine fallite per 14 giorni: nuova ricerca possibile entro pochi minuti.
- Immagini scaricate localmente e rese come JPEG ridimensionati, consegnati alla WebView come `data:image/jpeg;base64`, con riduzione dei problemi di WebView causati da URL locali fittizi.
- Se un catalogo non offre l'immagine verificabile, la scheda mostra **Locandina/Copertina non disponibile**, non una falsa copertina. Il recupero live non è stato provato su Samsung.
- Le condizioni di licenza di qualsiasi fornitore di poster devono essere verificate prima di una pubblicazione commerciale. I testi descrittivi sono editoriali; le immagini restano di terze parti.

### Grafica e dati
- Identità magica **azzurro, neve, rosso e oro** conservata.
- Testi e orari ingranditi nelle schede (CSS V15).
- 34 film e 16 libri, Calendario dell'Avvento, ricerca, preferiti e link esterni presenti; la disponibilità delle piattaforme non è in tempo reale.
- Numero di versione Android `15.0.0`, `versionCode 15`, pacchetto `it.ioamolamagiadelnatale`.
- **Non sono attivati annunci AdMob** né affiliate link Amazon nell'APK, fino alle necessarie autorizzazioni.

## Compilazione
Aprire la cartella che contiene `settings.gradle` in Android Studio; compilare `assembleDebug`. In alternativa caricare questo ZIP su GitHub, farlo estrarre a Codex e chiedere `gradle assembleDebug` con JDK 17 / SDK Android 35. Conservare il file finale `app/build/outputs/apk/debug/app-debug.apk`. L'APK è di test e NON è incluso in questo pacchetto.

## Test prioritari sul Samsung
1. Connessione Internet attiva; aprire Guida TV, premere «Aggiorna» e attendere il caricamento (massimo ~30s). Se la fonte risponde, appaiono canali, date e film, non soltanto il link esterno.
2. Aprire **Domani**; provare anche «Tutti i film trovati». Se compare «Non pubblicato», controllare la riga di errori della guida e il numero di date effettivamente coperte.
3. Aprire Film: verificare almeno `Klaus`, `Mamma, ho perso l’aereo`, `A Christmas Carol` e la relativa locandina **vera**. Attendere anche 30s con Internet attivo, poi riprovare `Ricarica locandine originali`.
4. Aprire Libri e verificare `Canto di Natale` e `Il Grinch` (titolo + autore). Le copertine editoriali possono dipendere dall'edizione.
5. Verificare Home e Calendario dell'Avvento, controllando che nessuna scheda rimanga bloccata.
6. **Se il feed non risponde, NON dichiarare la guida funzionante**: registrare l'errore mostrato nell'app, l'URL HTTPS coinvolto e il codice HTTP.

## Limiti verificati e non verificati
- Test sintattico JavaScript e navigazione web con dati TV sintetici: **eseguiti**.
- Verifica sintattica di Java con SDK Android, compilazione APK, risposte live di XMLTV e verifica dell'installazione: **NON eseguite in questo ambiente**.
- Una fonte pubblica accessibile via browser non implica licenza d'uso commerciale o disponibilità continua.
