package it.ioamolamagiadelnatale;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
    private static final String CHANNEL_ID = "film_natale_tv";
    static void ensureChannel(Context c){
        if(Build.VERSION.SDK_INT>=26){
            NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
            if(nm!=null)nm.createNotificationChannel(new NotificationChannel(CHANNEL_ID,
                "Film di Natale in TV",NotificationManager.IMPORTANCE_DEFAULT));
        }
    }
    @Override public void onReceive(Context context,Intent intent){
        ensureChannel(context);
        String title=intent.getStringExtra("title");
        String id=intent.getStringExtra("id");
        Intent open=new Intent(context,MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi=PendingIntent.getActivity(context,0,open,
            PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder=new Notification.Builder(context,CHANNEL_ID)
            .setContentTitle("🎄 Fra poco in TV")
            .setContentText(title==null?"Il tuo film di Natale sta per iniziare":title)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setAutoCancel(true)
            .setContentIntent(pi);
        NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        if(nm!=null)try{nm.notify(id==null?0:id.hashCode(),builder.build());}catch(SecurityException ignored){}
    }
}
